def ispalindrome(string):
    return "Is Palindrome" if string == string[::-1] else "Not Palindrome"